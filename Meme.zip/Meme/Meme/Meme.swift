//
//  Meme.swift
//  Meme
//
//  Created by Li, Xinli on 7/7/16.
//  Copyright © 2016 Li, Xinli. All rights reserved.
//

import Foundation
import UIKit

struct  Meme {
    var text:String = ""
    var image:UIImage
    var memedImage:UIImage
}